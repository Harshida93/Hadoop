
package org.sparkcore.training

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.Column
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date

object WithColumnExample {
  
  def main(args:Array[String]){
    val conf = (new SparkConf)
    .setAppName("RDD to Df example")
    .setMaster("local[*]")
    
    val sc = new SparkContext(conf)
    
    val spksessions = SparkSession.builder()
    .appName("RDD to Df example")
    .master("local[*]")
    .getOrCreate()
    
    val df = spksessions
    .read
    .option("header", true)
    .option("inferSchema", true)
    .csv("/Users/harshida/Downloads/SalesJanwithHeading.csv")
    .withColumn("ProcessingDate", lit(getformattedDate(new Date)))
    
    df.write
    .partitionBy("ProcessingDate")
    .option("header", true)
    .csv("/Users/harshida/Documents/test_data/output")
    
    
  }
  def getformattedDate(date : Date)={
    val dateformat = new SimpleDateFormat("yyyy-MM-dd")
    val formattedDate = dateformat.format(date)
    formattedDate
    
    
    
    
    
    
    
    
  }
}