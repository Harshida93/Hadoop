package org.sparkcore.training

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object SalesReport {
  def main(args:Array[String]){
    val conf = (new SparkConf)
    .setAppName("Sales Report Generator")
    .setMaster("local[*]")
    val sc = new SparkContext(conf)
    
    val rdd = sc.textFile("/Users/harshida/Downloads/SalesJan2009.csv")
    
    val maprdd = rdd.map(x=>{
      val elements =x.split(",")
      (elements(2).trim,elements(1).trim.toInt)
      })
      
      val aggrdd = maprdd.reduceByKey((x,y)=>x+y)
      
      aggrdd.foreach(element =>println(element._1+" = "+element._2))
  }
}