
package org.sparkcore.training

import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SaveMode

object HiveExample {
  def main(args:Array[String]){
    val conf =(new SparkConf)
    .setAppName("Hive example")
    .setMaster("local[*]")
    
    val sc = new SparkContext(conf)
    
    val spksession = SparkSession.builder()
    .appName("Hive example")
    .master("loca[*]")
    //.enableHiveSupport()
    .getOrCreate()
    
    val salesDf = spksession.read
    .option("header", true)
    .option("inferSchema",true)
    .csv("/Users/harshida/Downloads/SalesJanwithHeading.csv")
    
    spksession.sql("create database if not exists sales_db")
    spksession.sql("Use sales_db")
    
    salesDf.write.mode("overwrite").partitionBy("Country").saveAsTable("Sales")
    
  }
}