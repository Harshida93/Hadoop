package org.sparkcore.training

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.harshida.sparksql.Sales

object SparkSQL{

  def main(args: Array[String]){
    val conf =(new SparkConf)
    .setAppName("RDD to Df example")
    .setMaster("local[*]")
    
    val context = new SparkContext(conf)
    
    val spkSession = SparkSession.builder()
    .appName("RDD to Df example")
    .master("local[*]")
    .getOrCreate()
    
    val rdd = context.textFile("/Users/harshida/Documents/BDA 105/Week 2/SalesJan2009.csv")
    .map(x=>{
      val fields = x.split(",")
      new Sales(fields(0).trim(),fields(1).trim().toInt,fields(2).trim(),fields(3).trim(),fields(4).trim(),fields(5).trim(),
          fields(6).trim())
      
    })
   import spkSession.implicits._
   
   val df = rdd.toDF()
   df.show(10)
   
   val sumDf = df.groupBy("Paymenttype").sum("Salesamount")
   sumDf.show
  }
}
  
  
  
  
