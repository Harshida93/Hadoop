

package org.harshida.sparksql

case class Sales(ID : String ,Salesamount: Int,Paymenttype:String,Name:String,City:String,Region:String,Country:String){}