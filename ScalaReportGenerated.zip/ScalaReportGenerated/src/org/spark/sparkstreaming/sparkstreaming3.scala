

package org.spark.sparkstreaming

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming._
import org.apache.spark.streaming.StreamingContext._

object sparkstreaming3 {
  def main(args:Array[String]){
  val conf = (new SparkConf).setAppName("Count by Window").setMaster("local[*]")
  val streamingContext = new StreamingContext(conf, Seconds(2))
  
  streamingContext.checkpoint("/Users/harshida/Documents/BDA 105/test_data2/check_point")
  val DSstream1 = streamingContext.socketTextStream("localhost", 21)
  val windowCount = DSstream1.window(Seconds(10), Seconds(8))
  
  windowCount.foreachRDD(rdd=>{
    println("Hello")
    rdd.saveAsTextFile("/Users/harshida/Documents/BDA 105/test_data2/output")
  })
  
  
  streamingContext.start()
  streamingContext.awaitTermination()

  
}
  
}