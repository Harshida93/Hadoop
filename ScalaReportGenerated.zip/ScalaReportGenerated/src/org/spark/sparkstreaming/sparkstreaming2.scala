

package org.spark.sparkstreaming
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming._
import org.apache.spark.streaming.StreamingContext._

object sparkstreaming2 {
 def main(args:Array[String]){
  val conf = (new SparkConf).setAppName("Spark Streaming").setMaster("local[*]")
  val sc = new SparkContext(conf)
  val constantsRdd = createConstants(sc)
  val streamingContext = new StreamingContext(sc, Seconds(6))
  val DSstream1 = streamingContext.socketTextStream("localhost", 21)

  val unionWithConstant = DSstream1.transform(rdd=>rdd.union(constantsRdd))
      unionWithConstant.print()
  
  streamingContext.start()
  streamingContext.awaitTermination()

  
}
  def createConstants(sc:SparkContext)={
   val arr = Array("a","b","c","d","e")
   sc.parallelize(arr)
  }
}