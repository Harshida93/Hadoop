package org.spark.spark2.practice

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession

object germanData {
  def main(args:Array[String]){
    val conf = (new SparkConf)
    .setAppName("Project test")
    .setMaster("local[*]")
    
    val sc = new SparkContext(conf)
    
    val Spksession = SparkSession.builder()
    .appName("Project test")
    .master("local[*]")
    .getOrCreate()
    
    val rdd = sc.textFile("/Users/harshida/Documents/BDA 105/SparkProject/german.csv")
    .map(row=>{
     val cols = row.split(",")
     new germandataset(cols(0).trim().toDouble,cols(1).toDouble,cols(2).toDouble,cols(3).toDouble,cols(4).toDouble,cols(5).toDouble,cols(6).toDouble,cols(7).toDouble,cols(8).toDouble,cols(9).toDouble,cols(10).toDouble,cols(11).toDouble,
         cols(12).toDouble,cols(13).toDouble,cols(14).toDouble,cols(15).toDouble,cols(16).toDouble,cols(17).toDouble,cols(18).toDouble,cols(19).toDouble,cols(20).toDouble)
    })
  import Spksession.implicits._
  
  val germanDf=rdd.toDF()
  germanDf.registerTempTable("creditTBL")
  //germanDf.show()
  //germanDf.printSchema()
  //germanDf.groupBy("creditability").avg("amount").show
  Spksession.sql("Select * from creditTBL").show()
  
}
}