package org.mausam.kafkasample;

public class Initiator {

	public static void main(String[] args) throws Exception {
		Thread producer = new Thread(new KafkaSampleProducer());
		Thread consumer = new Thread(new KafkaSampleConsumer("kafka consumer"));
		
		producer.start();
		consumer.start();
		
		producer.join();
		consumer.join();
	}

}
