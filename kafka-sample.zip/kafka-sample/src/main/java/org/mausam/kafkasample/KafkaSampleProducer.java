package org.mausam.kafkasample;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

public class KafkaSampleProducer implements Runnable {
	
	private static final String TOPIC_NAME = "spark_topic";
	private static long ID;
	
	public void run() {
		
		Properties kafkaConfig = getConfig();
		Producer<String, String> producer = new KafkaProducer<String, String>(kafkaConfig);
			
		try {
			while (true) {
				Thread.sleep(1 * 1000);
				String messageKey = "Key" + ID;
				String messageValue = generateMessageContent();
				
				producer.send(new ProducerRecord<String, String>(
						TOPIC_NAME, messageKey, messageValue));
				System.out.println("Producer - " + messageKey + ": Message sent successfully");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			producer.close();
		}
	}
	
	private Properties getConfig() {
		Properties config = new Properties();
		config.put("bootstrap.servers", "localhost:9092");
		config.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		config.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		
		return config;
	}
	
	private static String generateMessageContent() {
		String name = "John" + ID++;
		return "{\"name\":\"" + name + "\", \"age\":31, \"city\":\"New York\"}";
	}

}
