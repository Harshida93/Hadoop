package org.mausam.kafkasample;

import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

public class KafkaSampleConsumer implements Runnable {
	
	private static final String TOPIC_NAME = "spark_topic";
	private String name;
	
	public KafkaSampleConsumer(final String name) {
		this.name = name;
	}

	public void run() {
		KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(getConfig());
		consumer.subscribe(Arrays.asList(TOPIC_NAME));

		try {
			while (true) {
				ConsumerRecords<String, String> records = consumer.poll(50);
				for (ConsumerRecord<String, String> record : records) {
					System.out.printf("Consumer - %s, Partition: %d, Offset: %d, %s, %s %n", 
							this.name, record.partition(), record.offset(), record.key(), record.value());
				}
				
				Thread.sleep(1 * 1000);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			consumer.close();
		}
	}
	
	private Properties getConfig() {
		Properties config = new Properties();
		config.put("bootstrap.servers", "localhost:9092");
		config.put("group.id", "test-consumer");
		config.put("enable.auto.commit", "true");
		config.put("auto.commit.interval.ms", "1000");
		config.put("connections.max.idle.ms", "1000");
		config.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		config.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		
		return config;
	}

}
