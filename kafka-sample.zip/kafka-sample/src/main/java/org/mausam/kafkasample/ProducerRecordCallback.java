package org.mausam.kafkasample;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.RecordMetadata;

public class ProducerRecordCallback implements Callback {

	public void onCompletion(RecordMetadata recordMetadata, Exception ex) {
		if (recordMetadata != null) {
			System.out.println("Record placed into partition " + recordMetadata.partition()
				+ " at offset " + recordMetadata.offset());
		} else {
			System.out.println("Exception while placing record: " + ex.getMessage());
		}
		
	}

}
